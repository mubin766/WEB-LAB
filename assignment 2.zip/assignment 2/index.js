function check()
{
    var a="",b="";
     a=document.getElementById("userneme").value;
     b=document.getElementById("password").value;
     
    if(a.length==0 && b.length==0)
    {
        //alert("submit the form a and b"+a+" "+b);
        document.getElementById("error").innerHTML="invaild credential";
    }
}