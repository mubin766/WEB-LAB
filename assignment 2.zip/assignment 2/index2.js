$(document).ready(function(){

    $("#submit_btn").click(
        function(){
            var f_name,Class,email,p_num,u_name,pass1,pass2;
            f_name=$("#full_name").val();
            Class=$("#class").val();
            email=$("#email").val();
            p_num=$("#number").val();
            u_name=$("#user_name").val();
            pass1=$("#pass1").val();
            pass2=$("#pass2").val();

            if(f_name=="" ||Class==""||email==""||pass1==""||pass2==""||p_num==""||u_name==""){
                document.getElementById("error").innerHTML="requires name";
            }

            if(!pass1.equals(pass2)){
                document.getElementById("error").innerHTML="requires name";
            }
            
        }
    );
    });